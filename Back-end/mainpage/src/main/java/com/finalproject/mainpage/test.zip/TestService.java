package com.finalproject.mainpage.test;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TestService {
	private final TestRepository testRepository;
	
	@Transactional
	public void save() {
		testRepository.save();
	}
	
}
